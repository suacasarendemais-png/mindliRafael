// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBDJPWaZLzb6rDaxxonAGIqGxxnxwgpEGM",
  authDomain: "mindilirafael1.firebaseapp.com",
  projectId: "mindilirafael1",
  storageBucket: "mindilirafael1.appspot.com",
  messagingSenderId: "124174402053",
  appId: "1:124174402053:web:cac0a1fc8cc9154dc5d26c"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);